# Summary: new sources for the Quantitative Finance KB

**Result: 27 new sources, not 50.** The target was 50 (5 per topic). I stopped at 27 because I would not add anything I could not check. The remaining 23 slots are unfilled and are listed under "Gap" below.

## How "verified" was decided
The sandbox had no network access, so I could not make direct HTTP requests. I verified each URL through the web search tool: a source counts as `VERIFIED_LIVE` only if the exact URL it lists returned the intended content (title, authors and abstract or text) in this session. No HTTP status codes were checked. Where a PDF link was not itself returned (for example an arXiv abstract page), the CSV lists the page that was seen and notes the PDF separately in `verification_notes`.

## Totals
- New sources: **27** (target 50)
- Duplicates found against all four of your files and my earlier outputs: **0** (checked by normalised URL and by arXiv ID)
- `VERIFIED_LIVE`: **27** · `VERIFIED_REDIRECT`: 0 · `ACCESS_BLOCKED`: 0 · `NOT_FOUND`: 0 · `UNVERIFIED`: 0 (unverifiable candidates were dropped, not listed)
- Access: **25 open**, **2 unknown** (both SSRN abstract pages; the abstract is free but I did not check the full-text download). No paywalled sources.

## By topic (target 5 each)
| Topic | Count | Short by |
|---|---|---|
| Financial Econometrics | 5 | 0 |
| Time Series Analysis | 5 | 0 |
| Algorithmic Trading | 4 | 1 |
| Market Microstructure | 3 | 2 |
| Fixed Income and Interest Rates | 2 | 3 |
| Backtesting and Strategy Evaluation | 2 | 3 |
| Cryptocurrency and DeFi | 2 | 3 |
| NLP for Finance | 2 | 3 |
| Credit Risk | 1 | 4 |
| Agent-Based Financial Models | 1 | 4 |

## By resource type
Research Paper 19 · Lecture Notes 5 · Official Report 2 · Documentation 1. There are no GitHub repositories, datasets or open textbooks yet, which is another reason the gap should be filled.

## Ten most useful sources
1. **Limit Order Books (Gould et al.)**: the standard LOB survey (stylized facts and models).
2. **DeepLOB (Zhang, Zohren, Roberts)**: the common deep-learning baseline for order book prediction.
3. **The Probability of Backtest Overfitting (Bailey et al.)**: an open, CC-licensed PDF with the standard overfitting test.
4. **U.S. Treasury Yield Curve 1961–present (Fed)**: official method behind a widely used yield curve dataset.
5. **BIS Papers No 25**: how central banks build zero-coupon curves (Nelson-Siegel, Svensson).
6. **Engle's Nobel lecture**: primary-source explanation of ARCH and volatility risk.
7. **Hawkes processes in finance**: survey linking order flow, execution and volatility.
8. **Credit Risk Modeling and Valuation (Giesecke)**: open introduction to structural and reduced-form credit models.
9. **ABIDES**: the open agent-based market simulator paper.
10. **Sheppard's Python for Econometrics (Oxford)**: code-oriented notes by the author of the `arch` package.

## Items needing a manual check
- **Almgren-Chriss (N13), Corsi (N09), Gu-Kelly-Xiu (N05)**: I confirmed metadata pages only; full-text access is unchecked.
- **arXiv 1403.2229 (N14) and 1206.0682 (N15)**: the retrieved text did not show authors, so authors are left as "not shown" and the year is taken from the arXiv ID.
- **Pseudo-Mathematics paper (N27)**: the retrieved title was truncated. The full title and year are from my own knowledge, and the PDF is an author-hosted copy.
- **Houston FINA 4397 notes (N02)**: the instructor name is inferred only from the URL path.
- **Tübingen course (N03)**: dated 2005, so the material is older.

## Gap: 23 sources still to find
Priority is the topics at 0–2 sources: Credit Risk, ABM, Crypto/DeFi, NLP, Backtesting, Fixed Income and Microstructure. I have candidate ideas but did not verify them, so they are not in the CSV: Loughran-McDonald sentiment dictionary, ABIDES GitHub repo, Bitcoin whitepaper, Uniswap v3 whitepaper, FinQA, Basel IRB explanatory note, a Diebold-Li yield curve paper, ECB yield curve page, backtrader or vectorbt docs, Mesa documentation. Each needs a verification pass before it is added.
